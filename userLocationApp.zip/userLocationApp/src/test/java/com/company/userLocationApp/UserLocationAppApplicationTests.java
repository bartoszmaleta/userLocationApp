package com.company.userLocationApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLocationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
